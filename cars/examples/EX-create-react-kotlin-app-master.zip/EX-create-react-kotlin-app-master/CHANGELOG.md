# 06.11.2018

kotlin-webpack-plugin@2.0.1, react-scripts-kotlin@3.0.1

* Minor fixes

# 02.11.2018

kotlin-webpack-plugin@2.0.0, react-scripts-kotlin@3.0.0

* **BREAKING CHANGE** Webpack 4
* **BREAKING CHANGE** Dropped support for Node versions earlier than 8.6 

# 30.10.2018

create-react-kotlin-app@1.0.11, kotlin-webpack-plugin@1.2.11, kotlinc-js-api@1.2.11, react-scripts-kotlin@2.1.15

* Kotlin 1.3.0
* React 16.6.0
* @jetbrains/kotlin-* packages updated to pre.58

# 26.09.2018

kotlin-webpack-plugin@1.2.10, kotlinc-js-api@1.2.10, react-scripts-kotlin@2.1.14

* Minor fixes

# 13.09.2018

create-react-kotlin-app@1.0.10, gen-idea-libs@1.0.11, kotlin-webpack-plugin@1.2.9, kotlinc-js-api@1.2.9, react-scripts-kotlin@2.1.12

* React 16.5.0
* @jetbrains/kotlin-* packages updated to pre.53
* Added an explicit dependency on core-js

# 22.08.2018

create-react-kotlin-app@1.0.9, kotlin-webpack-plugin@1.2.8, kotlinc-js-api@1.2.8, react-scripts-kotlin@2.1.12, ts2kt-automator@1.0.12

* Kotlin 1.2.61
* React 16.4.2
* @jetbrains/kotlin-* packages updated to pre.49
