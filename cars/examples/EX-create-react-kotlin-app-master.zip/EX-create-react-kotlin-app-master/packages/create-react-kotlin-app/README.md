# create-react-kotlin-app

This package includes the global command for [Create React Kotlin App](https://github.com/JetBrains/create-react-kotlin-app/).

To learn how to create apps in Kotlin using React, please refer to the [Getting Started Guide](https://github.com/JetBrains/create-react-kotlin-app/#quick-overview).