'use strict';
//All CLI arguments will pass into and parsed there
require('@jetbrains/ts2kt-automator');
