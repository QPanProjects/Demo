# react-scripts-kotlin

This package includes scripts and configuration used by [Create React Kotlin App](https://github.com/JetBrains/create-react-kotlin-app/).

To learn how to create apps in Kotlin using React, please refer to the [Getting Started Guide](https://github.com/JetBrains/create-react-kotlin-app/#quick-overview).