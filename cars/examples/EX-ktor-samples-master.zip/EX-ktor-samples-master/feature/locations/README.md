# Locations

Sample project for [Ktor](https://ktor.io) demonstrating _experimental_ locations feature.

## Running

Execute this command in the repository's root directory to run this sample:

```bash
./gradlew :locations:run
```
 
And navigate to [http://localhost:8080/](http://localhost:8080/) to see the sample home page.  
