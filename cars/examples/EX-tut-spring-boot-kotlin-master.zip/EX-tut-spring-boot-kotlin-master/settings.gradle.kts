pluginManagement {
	repositories {
		gradlePluginPortal()
	}
}
rootProject.name = "blog"