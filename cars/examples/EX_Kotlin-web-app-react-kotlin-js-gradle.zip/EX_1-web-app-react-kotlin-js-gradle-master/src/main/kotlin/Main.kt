import kotlin.browser.document

fun main() {
    document.bgColor = "blue"
}