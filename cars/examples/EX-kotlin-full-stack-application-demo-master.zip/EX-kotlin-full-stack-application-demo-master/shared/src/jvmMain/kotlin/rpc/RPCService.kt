package rpc

interface RPCService