plugins {
    id("org.jetbrains.kotlin.multiplatform") version "1.3.72" apply false
    id("kotlinx-serialization") version "1.3.72" apply false
}

allprojects {
    version = "0.1.1"
}
