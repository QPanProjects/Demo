package contrib.enzyme

@JsModule("enzyme-adapter-react-16")
external class AdapterReact16 : EnzymeAdapter
