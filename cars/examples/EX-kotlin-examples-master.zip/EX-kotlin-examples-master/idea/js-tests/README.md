A sample test condiguration for IDEA Ultimate. Requires the [NodeJs](https://plugins.jetbrains.com/plugin/6098-nodejs) plugin.

In order to run the tests, build the project, run `npm install` in the project directory,
and launch the 'Run tests' run configuration.
