package coffee

interface Pump {
    fun pump()
}
