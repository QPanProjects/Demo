
Kotlin MPP Module
=================


An example project of an Kotlin MPP = Multiplatform project for Android and iOS

LICENSE
=======

Apache 2.0


