package org.kotlin.mpp.mobile

actual fun platformName(): String {
  return "Android"
}

