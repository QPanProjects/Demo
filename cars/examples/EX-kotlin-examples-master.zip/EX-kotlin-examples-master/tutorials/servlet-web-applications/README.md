Code for the [Creating Web Applications with Http Servlets](http://kotlinlang.org/docs/tutorials/httpservlets.html) tutorial.

To run this from command line, we can use [gretty], a gradle plugin to run the application war under Jetty.

Run this command to start the app:-

    gradle appStart

References - https://www.petrikainulainen.net/programming/gradle/getting-started-with-gradle-creating-a-web-application-project/

[gretty]:https://github.com/akhikhl/gretty/blob/master/changes.md
