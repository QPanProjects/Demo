package org.jetbrains.kotlin.demo

data class Greeting(val id: Long, val content: String)
