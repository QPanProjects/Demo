Sample project for the [Karma](https://karma-runner.github.io/1.0/index.html) test runner.
The unit testing framework used in this example is [Mocha](https://mochajs.org/).
