Sample projects using various test frameworks. Requires Kotlin version 1.1.4-eap-33 or later.
 
In order to run the tests run `./gradlew test` in the corresponding folder.
