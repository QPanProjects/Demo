Sample project for [Mocha](https://mochajs.org/) unit testing framework.
