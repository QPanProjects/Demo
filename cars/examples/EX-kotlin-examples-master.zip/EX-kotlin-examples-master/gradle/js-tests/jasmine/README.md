Sample project for [Jasmine](https://jasmine.github.io/) unit testing framework.
