Sample project for [Tape](ttps://github.com/substack/tape) unit testing framework.
It is not supported out of the box, so it requires a custom `tape-plugin.js`.

This example shows how to configure a custom unit testing framework to run Kotlin tests.
