Sample project for [QUnit](http://qunitjs.com) unit testing framework.
