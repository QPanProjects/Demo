Sample project for the [kotlin-frontend-plugin](https://github.com/Kotlin/kotlin-frontend-plugin).
Uses [QUnit](http://qunitjs.com/) unit testing framework with [Karma](https://karma-runner.github.io/1.0/index.html) runner.

