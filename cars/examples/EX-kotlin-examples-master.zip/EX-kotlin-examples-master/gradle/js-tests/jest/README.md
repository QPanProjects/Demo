Sample project for [Jest](https://facebook.github.io/jest/) unit testing framework.
This example also shows how make `npm test` launch the tests.

Beware that current version of Jest doesn't work well when package.json is absent.
