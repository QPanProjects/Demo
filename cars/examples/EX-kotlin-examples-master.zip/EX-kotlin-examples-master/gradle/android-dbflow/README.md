# kotlin-poc
A test using Kotlin (kapt) + DBFlow
