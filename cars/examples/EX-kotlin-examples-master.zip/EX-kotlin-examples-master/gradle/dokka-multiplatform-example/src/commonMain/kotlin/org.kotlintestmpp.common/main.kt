package org.kotlintestmpp.common

class Foo {}

