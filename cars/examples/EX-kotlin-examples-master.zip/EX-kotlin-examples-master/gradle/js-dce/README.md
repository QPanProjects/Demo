This sample project shows how to use Kotlin DCE and webpack to get a small bundle.

To build the project, simply run `./gradlew build`,
then open `index.html` in the browser.
 