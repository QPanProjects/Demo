
Here is how to get started with the project `mixed-java-kotlin-hello-world`

- set `sdk.dir` to your `$ANDROID_HOME` in `gradle/android-mixed-java-kotlin-project/local.properties`
- Start IntelliJ or Android Studio and choose `Import Project` 
- Choose directory `kotlin-examples/gradle/android-mixed-java-kotlin-project`
- Choose `Import project from external model > Gradle`
- Use customizable gradle wrapper > Finish




