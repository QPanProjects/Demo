package model1

enum class HeightBucket {
    SHORT, AVERAGE, TALL
}