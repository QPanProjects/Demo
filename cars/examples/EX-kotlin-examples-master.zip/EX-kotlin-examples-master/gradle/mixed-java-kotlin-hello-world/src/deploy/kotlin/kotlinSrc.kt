package demo 

class ExampleSource(param: Int) {
    val property = param

    fun f(): String {
        return "Hello World"
    }
}
