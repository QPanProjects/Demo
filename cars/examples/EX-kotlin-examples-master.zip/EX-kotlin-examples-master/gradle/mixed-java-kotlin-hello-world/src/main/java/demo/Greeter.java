package demo;

public class Greeter {
    private final String myGreeting;

    public Greeter(String greeting) {
        myGreeting = greeting;
    }

    public String getGreeting() {
        return myGreeting;
    }
}
