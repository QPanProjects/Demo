
Some tips to use this project in the IDE (Android Studio or IDEA):

- After opening the project check Build Variants tool window and make sure Test Artifact = Unit Tests.

