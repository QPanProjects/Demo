# kotlinant

Example configuration using Ant for Dokka.

1. Install Ant.
2. Set path to Dokka's fatjar in build.xml. 
3. Run in console: 
```
ant document
```
your documentation will be located at `ant/dokka-ant/doc`.

To clean, run:
```
ant clean
```