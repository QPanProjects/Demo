package commonMain.kotlin.org.foo


/**
 * just foo class
 */
class Foo {

    fun bar(): Int = 0
}